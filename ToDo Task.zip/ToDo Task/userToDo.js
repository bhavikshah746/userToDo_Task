/*Script file for User ToDo Task. 
The code in this script will send a request to "todos" API "http://jsonplaceholder.typicode.com/" and get a response if requested parameters are valid.*/

var USER_API = "http://jsonplaceholder.typicode.com/users"; //Global variable to store USERS API link
var TODOS_API = "http://jsonplaceholder.typicode.com/todos"; //Global variable to store TO DO API link

//doTask function to perform core functionality of this task. It will get userId based on username and then find task details of a particular user.
function doTask()
{
    $('#userTaskTbl').text('');
    var userName = $('#userName').val();
    if(userName === '' || userName === undefined) //check if userName is empty/undefined
    {
        alert("Please enter a username.");
        return;
    }

    var userID = getUserID(userName); //get user id
    if(userID === '' || userID === undefined) //check if userID is null or undefined.
    {
        alert('Username does not exist. Please enter a valid username.');
        return;
    }

    var taskObj = getTasks(userID); // get task object for given user id
    var headerRow = $('<tr>');
    var dataRow = $('<tr>');

    //taskObj loop to create task table
    for (taskSummary in taskObj)
    {
        headerRow.append('<th>'+taskSummary);
        if(taskSummary === 'All open tasks')
        {
            var table = $('<table>'); 
            for(tasks in taskObj[taskSummary])
            {
                table.append($('<tr>').append('<td>'+taskObj[taskSummary][tasks]+'</td>'));
            }
            dataRow.append($('<td>').append(table));
        }
        else
        {
            dataRow.append('<td>'+taskObj[taskSummary]);
        }
    }
    //End of loop

    $('#userTaskTbl').append(headerRow).append(dataRow);
}

//function to get user id based on username
function getUserID(userName)
{
    var userArray = ajaxRequest(USER_API);
    for(index in userArray)
    {
        if(userName.toLowerCase() === userArray[index].username.toLowerCase())
        {
            return userArray[index].id;
        }
    }
}

//function to get all the task details of a user based on user id
function getTasks(userID)
{
    var openToDoTaskArray =[]; //Array to store open task name
    var completedTask =0; //variable to store total completed tasks
    var openTask =0; //variable to store total open taks.
    var userTaskArray = ajaxRequest(TODOS_API);

    for(index in userTaskArray)
    {
        if(userTaskArray[index].userId === userID)
        {
            if(userTaskArray[index].completed === true)
            {
                completedTask++;
            }
            else if(userTaskArray[index].completed === false)
            {
                openTask++;
                openToDoTaskArray.push(userTaskArray[index].title);
            }
        }
    }
    //return open and completed tasks details in an Object.
    return {"Number of completed tasks":completedTask, "Number of open tasks": openTask, "All open tasks": openToDoTaskArray};
}

//common function for AJAX requests
function ajaxRequest(API)
{
    var ajaxResponse ='';
    request = $.ajax({
        url: API,
        type: "GET",
        async: false,
        success: function (response)
        {
            if(response!== '' && response!= undefined)
            {
                ajaxResponse= response;
            }
        },error: function (request)
        {
            alert(JSON.parse(request.responseText.message));
            return;
        }
    });
    return ajaxResponse;
}